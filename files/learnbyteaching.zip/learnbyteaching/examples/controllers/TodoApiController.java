package learnbyteaching.examples.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import learnbyteaching.examples.repositories.dao.TodoRepository;
import learnbyteaching.examples.repositories.vo.TodoItem;

@RequestMapping("/api/todos")
@RestController
@CrossOrigin("http://localhost")
//@CrossOrigin("http://localhost", 
//	methods= {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE},
//	allowedHeaders= {"Content-Type", "Authorization"})
public class TodoApiController {
	@Autowired
	private TodoRepository todoRepository;
	
    // 모든 TODO 항목 조회
    @GetMapping
    public ResponseEntity<List<TodoItem>> getAllTodos() {
        List<TodoItem> todos = todoRepository.findAll();
        return ResponseEntity.ok(todos);
    }

    // 특정 TODO 항목 조회
    @GetMapping("/{id}")
    public ResponseEntity<TodoItem> getTodoById(@PathVariable("id") Long id) {
        Optional<TodoItem> todo = todoRepository.findById(id);
        return todo.map(ResponseEntity::ok)
                   .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 새로운 TODO 항목 생성
    @PostMapping
    public ResponseEntity<TodoItem> createTodo(@RequestBody TodoItem todoItem) {
        TodoItem savedTodo = todoRepository.save(todoItem);
        return ResponseEntity.ok(savedTodo);  // ResponseEntity.created()를 사용하는 것이 나을지도 (201)
    }

    // 기존 TODO 항목 수정
    @PutMapping("/{id}")
    public ResponseEntity<TodoItem> updateTodo(@PathVariable Long id,
                                               @RequestBody TodoItem updatedTodo) {
        return todoRepository.findById(id)
                .map(todo -> {
                    todo.setTitle(updatedTodo.getTitle());
                    todo.setCompleted(updatedTodo.isCompleted());
                    TodoItem savedTodo = todoRepository.save(todo);
                    return ResponseEntity.ok(savedTodo);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // TODO 항목 삭제
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTodo(@PathVariable Long id) {
        Optional<TodoItem> existingTodo = todoRepository.findById(id);
        if (!existingTodo.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        todoRepository.deleteById(id);
        return ResponseEntity.ok().<Void>build();
    }
}
